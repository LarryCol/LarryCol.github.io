dict1 = {
    1: '1',
    2: '1 D',
    3: '1 D O',
    4: '1 D O D',
    5: '1 D O D O'
    }
for i in dict1:
    print(dict1[i])
    
# output
# 1
# 1 D
# 1 D O
# 1 D O D
# 1 D O D O