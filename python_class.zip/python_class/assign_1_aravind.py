s = 8 + 9j
print('Data type of s -',type(s))
list1 = [92, "Hello", "python", "words", 32]
print("python" in list1)
print(45 not in list1)