#second question
L1 = ['hello',[23, 98, '232'], 'world', 'good', 2]
print(L1)
L2 = ['myQ', ['everyone', 'hello'], 34, 66]
if 'hello'in L1:
    x = L1.index('hello', 0 , len(L1))
    L1.pop(x)
    L1.insert(x, 'goodbye')
print(L1)
print()
print(L2)
L2[1][1] = 'goodbye'
print(L2)
# output
# ['hello', [23, 98, '232'], 'world', 'good', 2]
# ['goodbye', [23, 98, '232'], 'world', 'good', 2]
#
# ['myQ', ['everyone', 'hello'], 34, 66]
# ['myQ', ['everyone', 'goodbye'], 34, 66]