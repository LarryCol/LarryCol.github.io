#aravind
class parent1:    
    def __init__(self):
        pass
    def func1(self):
        print('PARENT 1')

class parent2:
        def __init__(self):
            pass
        def func2(self):
            self.x = int(input('enter a number '))
            self.y = self.x * 2
            print('{} * 2 = {}'.format(self.x,self.y))

class child1(parent1,parent2):
        def __init__(self):
            pass
        def func3(self):
            print('this print line is from child only')
            print(parent1.func1(self))
            parent2.func2(self)
        
        def func1(self):
            print('This shows overriding')
            
    