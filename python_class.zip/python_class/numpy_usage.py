import numpy as np
np.array(['a','b','c'])
my_list = [1,2,3,4]
print(my_list)
my_array = np.array(my_list)
print(my_array)
my_matrix = [[1,2,3],[4,5,6],[7,8,9]]
ar = np.array(my_matrix)
print(ar)
