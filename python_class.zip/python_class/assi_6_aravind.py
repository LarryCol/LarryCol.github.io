class String_Func:
    s1 = ''
    x3= 0
    def __init__(self, word1, word2):
        self.x1 = word1
        self.y1 = word2
    
    def reverse(self):
        print(self.x1[::-1])
        print(self.y1[::-1])
    
    def slicing(self):
        print(self.x1[0:len(self.x1):2])
        print(self.y1[2:len(self.y1)])
    def permu(self):
        from itertools import permutations
        self.permList1 = permutations(self.x1)
#         permList2 = permutations(self.x1)
        print(permList1)
        for perm in self.permList1:
            print(''.join(perm))
#         for perm in permList2:
#             print(''.join(perm))
    def substri(self):
        self.x2 = input('enter a word or sentence')
        def __index__(self):
           return len(self.x2)
        print('example for substrings of entered string')
#         for i in self.x2:
#             slic_str = self.x2[0:self:i]
#             print(slic_stri)
        print('orginal:',self.x2)
        print('substr1:',self.x2[__index__(self) - 4:__index__(self):1])
        print('substr2:',self.x2[0:__index__(self):2])
    