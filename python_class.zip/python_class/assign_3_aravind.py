list0 = [0, 0, 0] #first way
str1 = ''
list4 = []

list1 = [0] * 3 #second way

list2 = list(str1) #third way
i = 0
while i < 3:
    list2.insert(i, 0)
    i += 1

list3 = list(str1) #fourth way
for i in range(0,3):
    list3.append(0)

print('list0', list0, 'list1', list1, 'list2', list2, 'list3', list3)

y = int(input('what is 100 - 100 = ? ')) #fifth way
for x in range(0,3):
    list4.insert(x,y)
print('list4', list4)
print()

#output
# list0 [0, 0, 0] list1 [0, 0, 0] list2 [0, 0, 0] list3 [0, 0, 0]
# what is 100 - 100 = ? 0
# list4 [0, 0, 0]

#second question
L1 = ['hello',[23, 98, '232'], 'world', 'good', 2]
print(L1)
L2 = ['myQ', ['everyone', 'hello'], 34, 66]
if 'hello'in L1:
    x = L1.index('hello', 0 , len(L1))
    L1.pop(x)
    L1.insert(x, 'goodbye')
print(L1)
print()
print(L2)
L2[1][1] = 'goodbye'
print(L2)
# output
# ['hello', [23, 98, '232'], 'world', 'good', 2]
# ['goodbye', [23, 98, '232'], 'world', 'good', 2]
#
# ['myQ', ['everyone', 'hello'], 34, 66]
# ['myQ', ['everyone', 'goodbye'], 34, 66]
