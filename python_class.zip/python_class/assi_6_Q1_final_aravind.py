class String_Func:
    
    def __init__(self):
        pass
    
    def reverse(self):
        self.x = input('enter a word or sentence ')
        print(self.x[::-1])
#         print(self.x1[::-1])
#         print(self.y1[::-1])
    
    def slicing(self):
        self.y = input('enter a word or sentence ')
        print('eg. for slicing:',self.y[0:len(self.y):2])
        print('eg. for slicing:',self.y[0:len(self.y)-3:1])
    
    def permu(self):
        from itertools import permutations
        self.w = input('enter a two to four letter word  ')
        self.permList1 = permutations(self.w)
        print('all the permutations of the word are as ')
        for perm in self.permList1:
            print(''.join(perm))
    def substri(self):
        self.z = input('enter a word or sentence ')
        self.v = len(self.z)
        print('example for substrings of entered string')
        print('orginal:',self.z)
        print('substr1:',self.z[0:self.v-2])
        print('substr2:',self.z[self.v-4:self.v])

# p1 = String_Func()
# print('class ready for called by object p1')
# print('use functions reverse(), slicing(), permu(), substri()')