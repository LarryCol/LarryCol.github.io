l1 = []
for i in range(0,5):
    x = float(input('enter a number '))
    if x in l1:
        x = float(input('Number alredy entered.Enter a different number '))
        l1.append(x)
    else:
        l1.append(x)
        continue
    
print(l1)
dict2 = {y: y**3 for y in l1}
print(dict2)

#output
# enter a number 5
# enter a number 4
# enter a number 3
# enter a number 2
# enter a number 1
# [5.0, 4.0, 3.0, 2.0, 1.0]
# {5.0: 125.0, 4.0: 64.0, 3.0: 27.0, 2.0: 8.0, 1.0: 1.0}