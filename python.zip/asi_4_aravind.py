dict1 = {
    1: '1',
    2: '1 D',
    3: '1 D O',
    4: '1 D O D',
    5: '1 D O D O'
    }
for i in dict1:
    print(dict1[i])
# 
# list1 = [1, 'D', 'O']
l1 = []
for i in range(0,5):
    x = float(input('enter a number'))
    l1.append(x)
print(l1)
dict2 = {y: y**3 for y in l1}
print(dict2)