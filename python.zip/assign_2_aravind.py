for i in range(1,51):
    if(i % 3 == 0 and i % 5 == 0):
        print('BLACK CAT')
    elif(i % 3 == 0):
        print('CAT')
    elif(i % 5 == 0):
        print('BLACK')
    else:
        print(i)

# output
# 1
# 2
# CAT
# 4
# BLACK
# CAT
# 7
# 8
# CAT
# BLACK
# 11
# CAT
# 13
# 14
# BLACK CAT
# 16
# 17
# CAT
# 19
# BLACK
# CAT
# 22
# 23
# CAT
# BLACK
# 26
# CAT
# 28
# 29
# BLACK CAT
# 31
# 32
# CAT
# 34
# BLACK
# CAT
# 37
# 38
# CAT
# BLACK
# 41
# CAT
# 43
# 44
# BLACK CAT
# 46
# 47
# CAT
# 49
# BLACK
