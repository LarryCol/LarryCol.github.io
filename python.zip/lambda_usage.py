cube = lambda a:a**3
average= lambda a,b:(a+b)/2
from functools import reduce
l4=[1,2,3,4,5]
print(reduce(average,l4)) #works
for i in l4:
    print(reduce(cube,i)) #error